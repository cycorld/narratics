#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Starting Narratics Studio..."
PORT=3901 "$DIR/narratics"
